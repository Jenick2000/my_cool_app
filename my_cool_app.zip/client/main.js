import '../imports/startup/accounts-config.js';
import '../imports/ui/layouts/body';
import '../lib/router.js';

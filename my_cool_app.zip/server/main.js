import { Meteor } from 'meteor/meteor';
import '../imports/api/tasks.js';
import '../imports/api/todos.js';
Meteor.startup(() => {
  // code to run on server at startup
  
});
